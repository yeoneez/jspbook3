drop table member;

CREATE TABLE  member(
   id VARCHAR2(30),
   passwd  VARCHAR2(30),
   name VARCHAR2(50),    
   PRIMARY KEY (id)
);

SELECT *  FROM user_tables;

select * from member;

